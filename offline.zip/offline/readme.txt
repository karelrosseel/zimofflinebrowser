
ZIM is a JavaScript Canvas Framework at https://zimjs.com

ZIM is usally used online - see the template at https://zimjs.com/code.html 

BUT... ZIM can be used offline with no Internet.

This ZIP file holds an example.

	1. UNZIP the ZIP file.

	2. Double click or drag the index.html page to a Browser.

	3. Edit the file in an Editor such as VS Code.

	4. Refresh the page in the browser (CTRL or CMD R)

WHY USE OFFLINE?

We might want to present art without worrying about Internet connection.

We often do light shows in clubs and it is easier not to connect.

Schools sometimes have poor or no connections.

Etc.

NOTE:

We will try and keep the ZIP up-to-date.

But if not up-to-date, just go get the latest at https://zimjs.com/cdn

